/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package redflix_app.app.modelos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/**

 */
@Entity
@Table(name = "series")
public class Serie {
    @Id
    @Column(name="titulo")
    String serTitulo;
    
    @Column(name="temporadas")
    Long serTemp;
    
    @Column(name="episodios")
    Long serEpisodio;

    public String getSerTitulo() {
        return serTitulo;
    }

    public void setSerTitulo(String serTitulo) {
        this.serTitulo = serTitulo;
    }

    public Long getSerTemp() {
        return serTemp;
    }

    public void setSerTemp(Long serTemp) {
        this.serTemp = serTemp;
    }

    public Long getSerEpisodio() {
        return serEpisodio;
    }

    public void setSerEpisodio(Long serEpisodio) {
        this.serEpisodio = serEpisodio;
    }
    
    @Override
    public String toString() {
        return "Serie {" + "Titulo=" + serTitulo + ", Temporadas=" + serTemp + ", Episodios=" + serEpisodio +'}';
    }

}
