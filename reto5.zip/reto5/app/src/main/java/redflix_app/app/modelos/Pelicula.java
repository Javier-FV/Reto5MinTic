/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package redflix_app.app.modelos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/**

 */
@Entity
@Table(name = "peliculas")
public class Pelicula {
    @Id
    @Column(name="titulo")
    String pelTitulo;
    
    @Column(name="resumen")
    String pelResumen;
    
    @Column(name="ano")
    Long pelAno;
    
    @Column(name="nombre_director")
    String pelNombreDir;
    
    @Column(name="apellido_director")
    String pelApellidoDir;

    public String getPelTitulo() {
        return pelTitulo;
    }

    public void setPelTitulo(String pelTitulo) {
        this.pelTitulo = pelTitulo;
    }

    public String getPelResumen() {
        return pelResumen;
    }

    public void setPelResumen(String pelResumen) {
        this.pelResumen = pelResumen;
    }

    public Long getPelAno() {
        return pelAno;
    }

    public void setPelAno(Long pelAno) {
        this.pelAno = pelAno;
    }

    public String getPelNombreDir() {
        return pelNombreDir;
    }

    public void setPelNombreDir(String pelNombreDir) {
        this.pelNombreDir = pelNombreDir;
    }

    public String getPelApellidoDir() {
        return pelApellidoDir;
    }

    public void setPelApellidoDir(String pelApellidoDir) {
        this.pelApellidoDir = pelApellidoDir;
    }
    
    @Override
    public String toString() {
        return "Pelicula {" + "Titulo=" + pelTitulo + ", Resumen=" + pelResumen + ", Año=" + pelAno + ", Director=" + pelNombreDir + " " +pelApellidoDir + '}';
    }
}