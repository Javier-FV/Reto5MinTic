/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package redflix_app.app;

import java.util.List;
import redflix_app.app.modelos.Serie;
import redflix_app.app.repositorios.SerieRepositorio;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
/**

 */
@Component
public class MyRunner implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(MyRunner.class);

    @Autowired
    private SerieRepositorio serieRep;
    
    @Override
    public void run(String... args) throws Exception {
        /*
        Pelicula peli = new Pelicula();
        peli.setPelTitulo("Guason");
        peli.setPelResumen("Pelicula de suspenso basada en el personaje de DC Comics Joker que se remonta a los orígenes del personaje con profundo análisis social");
        peli.setPelNombreDir("Todd");
        peli.setPelApellidoDir("Phillips");
        
        System.out.println(peli);
        
        serieRepositorio.save(peli);
        logger.info("Pelicula guardada: {}", peli);
        
        List <Serie> serie = serieRep.findAll();
        logger.info("{}", serie);
        
        logger.info("------------------------");*/
    }
}