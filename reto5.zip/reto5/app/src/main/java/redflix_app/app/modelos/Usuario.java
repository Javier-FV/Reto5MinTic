/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package redflix_app.app.modelos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/**

 */
@Entity
@Table(name = "usuarios")
public class Usuario {
    @Id
    @Column(name="alias")
    String userAlias;
    
    @Column(name="nombre")
    String userNombre;
    
    @Column(name="apellido")
    String userApellido;
    
    @Column(name="email")
    String userEmail;
    
    @Column(name="celular")
    Long userCelular;
    
    @Column(name="contrasena")
    String userContra;

    public String getUserAlias() {
        return userAlias;
    }

    public void setUserAlias(String userAlias) {
        this.userAlias = userAlias;
    }

    public String getUserNombre() {
        return userNombre;
    }

    public void setUserNombre(String userNombre) {
        this.userNombre = userNombre;
    }

    public String getUserApellido() {
        return userApellido;
    }

    public void setUserApellido(String userApellido) {
        this.userApellido = userApellido;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public Long getUserCelular() {
        return userCelular;
    }

    public void setUserCelular(Long userCelular) {
        this.userCelular = userCelular;
    }

    public String getUserContra() {
        return userContra;
    }

    public void setUserContra(String userContra) {
        this.userContra = userContra;
    }
    
    @Override
    public String toString() {
        return "Usuario {" + "Alias=" + userAlias + ", Nombre=" + userNombre + ", Apellido =" + userApellido +'}';
    }

}
